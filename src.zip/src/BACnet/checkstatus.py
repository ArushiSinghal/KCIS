import os
os.system("sshpass -p 'mouni1995' ssh 'user@10.2.24.157' 'cd pybacnet;cd tools;python checkstatus.py' ")

