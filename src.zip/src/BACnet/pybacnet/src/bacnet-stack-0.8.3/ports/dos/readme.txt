This is a port to DOS using the BACnet MS/TP datalink layer.
It utilizes some serial routines from snippets.org.
It was tested and compiled with Turbo C++ 1.01 which is 
freely available from http://dn.codegear.com/article/21751
It was targeting the TS-3100 from Technologic Systems.
