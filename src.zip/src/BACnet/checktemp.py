import os
os.system("sshpass -p 'mouni1995' ssh 'lingam@10.2.24.202' 'cd pybacnet;cd tools;python checktemp.py' ")

